package com.example.uitest;



import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.TileOverlay;
import com.google.android.gms.maps.model.TileOverlayOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.maps.android.heatmaps.Gradient;
import com.google.maps.android.heatmaps.HeatmapTileProvider;
import com.google.maps.android.heatmaps.WeightedLatLng;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class mapactivity extends FragmentActivity implements OnMapReadyCallback {
    String[] carrier = {"All Operators", "Jio", "Airtel","Vodafone"};
    String carriervalue;
    Location currentlocation;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int REQUEST_CODE = 101;
    Intent intent;
    Spinner spinner;
    private GoogleMap mMap;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapactivity);
        spinner = (Spinner) findViewById(R.id.spinner1);
        spinner.setPrompt("Select Operator");
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        fetchLastLocation();
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(mapactivity.this, R.layout.style_spinner1, carrier);
        //spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(android.R.layout.select_dialog_singlechoice);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onClick(View v) {

            }

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 1:
                        intent = new Intent(mapactivity.this, mapactivity.class);
                        startActivity(intent);
                        break;
                    case 2:
                      //  intent = new Intent(mapactivity.this, mapactivity.class);
                        //startActivity(intent);
                        break;
                    case 3:
                       // intent = new Intent(mapactivity.this, mapactivity.class);
                        //startActivity(intent);
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub

            }
        });
    }




    private void fetchLastLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]
                    {Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
            return;
        }

        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    currentlocation = location;
                    Toast.makeText(getApplicationContext(), currentlocation.getLatitude() + "" + currentlocation.getLongitude(), Toast.LENGTH_SHORT).show();
                    SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                            .findFragmentById(R.id.mMap);
                    mapFragment.getMapAsync(mapactivity.this);

                }
            }

        });
    }


    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng point = new LatLng(currentlocation.getLatitude(), currentlocation.getLongitude());
        //mMap.animateCamera(CameraUpdateFactory.newLatLng(point));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(point, 20));
        mMap.addMarker(new MarkerOptions().position(point).title("current location"));
        addHeatmap();
    }

    private void addHeatmap() {
        int[] colors={
                Color.rgb(255,0,0),
                Color.rgb(255,255,0),
                Color.rgb(102,255,0),


        };
        float[] startPoints={0.1f,0.4f,0.7f};
        Gradient gradient=new Gradient(colors,startPoints);
        ArrayList<WeightedLatLng> list = null;
        try {
            list = readItems(R.raw.heatmap_data);
        } catch (JSONException e) {
            Toast.makeText(this, "Problem reading list of locations.", Toast.LENGTH_LONG).show();
        }
        HeatmapTileProvider mProvider = new HeatmapTileProvider.Builder()
                .weightedData(list)
                .gradient(gradient)
                .radius(30)
                .opacity(0.9)
                .build();
        // Add a tile overlay to the map, using the heat map tile provider.
        TileOverlay mOverlay = mMap.addTileOverlay(new TileOverlayOptions().tileProvider(mProvider));
    }

    private ArrayList<WeightedLatLng> readItems(int resource) throws JSONException {
        ArrayList<WeightedLatLng> list = new ArrayList<WeightedLatLng>();
        InputStream inputStream = getResources().openRawResource(resource);
        String json = new Scanner(inputStream).useDelimiter("\\A").next();
        JSONObject jsonObject = new JSONObject(json);
        for (Iterator<String> it = jsonObject.keys(); it.hasNext(); ) {
            String i = it.next();
            JSONObject object = jsonObject.getJSONObject(i);
            double lat = object.getDouble("latitude");
            Log.i("Heatmap", String.valueOf(lat));
            double lng = object.getDouble("longitude");
            double intensity = object.getDouble("tag") + 1;
            //mMap.addMarker(new MarkerOptions().position(new LatLng(lat, lng))
            // .title(String.valueOf(intensity)));
            list.add(new WeightedLatLng(new LatLng(lat, lng), intensity));
        }
        return list;
    }


}




